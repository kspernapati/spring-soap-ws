package com.soapconsume.wscheck;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WscheckApplicationTests {

	@Test
	public void contextLoads() {
	}

}
