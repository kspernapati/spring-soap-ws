package com.soapconsume.wscheck.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.skd.soapconsume.generated.GetMovieByIdRequest;
import com.skd.soapconsume.generated.GetMovieByIdResponse;
import com.skd.soapconsume.generated.MovieType;

public class MovieClient extends WebServiceGatewaySupport{
	
	private static final Logger log = LoggerFactory.getLogger(MovieClient.class);
	
	public GetMovieByIdResponse getMovieById(GetMovieByIdRequest getMovReq) {
		
	//	GetMovieByIdRequest request = new GetMovieByIdRequest();
	//	request.setMovieId(movieType);
		
		log.info("Requesting movie by id: "+getMovReq);
		
		
		return (GetMovieByIdResponse) getWebServiceTemplate().marshalSendAndReceive(getMovReq);
	} 
}
