package com.soapconsume.wscheck;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.skd.soapconsume.generated.GetMovieByIdRequest;
import com.skd.soapconsume.generated.GetMovieByIdResponse;
import com.skd.soapconsume.generated.ObjectFactory;
import com.soapconsume.wscheck.client.MovieClient;
import com.soapconsume.wscheck.client.config.SoapClientConfig;

public class WscheckApplication {

    private static AnnotationConfigApplicationContext context;

	public static void main(String[] args) {
        context = new AnnotationConfigApplicationContext(SoapClientConfig.class);
        MovieClient client = context.getBean(MovieClient.class);

        GetMovieByIdRequest getMovReq = new ObjectFactory().createGetMovieByIdRequest();
        getMovReq.setMovieId(101);
        
        GetMovieByIdResponse response = client.getMovieById(getMovReq);
       System.out.println("response: Movie id="+ response.getMovieType().getMovieId()+", title=" + response.getMovieType().getTitle() + ", category="+ response.getMovieType().getCategory());
    }

}
